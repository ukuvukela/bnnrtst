var adDiv;

var stepDelay = 29;
var step = 1;
var stepCount = 0;
var newEF = 1;
var fps = 50;
var now;
var then = Date.now();
var interval = 1000/fps;
var delta;
var mode = 0;


function mob(id) {
  return document.getElementById(id);
}

function style(id) {
  return document.getElementById(id).style;
}


function IsImageOk(img) { 

if (!img.complete) { 
  return false; 
}

return true; 
}


function checkImages() { 
var ok = 1;
var sum = document.images.length;
var ss = 0;
for (var i = 0; i < document.images.length; i++) { 
  if (!IsImageOk(document.images[i])) {
  
  }  else ss++;
} 


if (sum==ss) ok = 1; else ok = 0;
return ok;
}

window.onload = function() {
  var iid = setInterval(function(){
    if (checkImages()) {
	   clearInterval(iid);
	   document.getElementById("ad").style.display = "block";
		
			console.log("start Ad..");
			startAd();
	}
  }, 100);

  
};


function startAd() {
    adDiv = document.getElementById("ad");

    addEventListeners();

	step = 2;
	
	if(typeof requestAnimationFrame === 'undefined') newEF = 0;

	if (newEF) requestAnimationFrame(fun1); else
	setTimeout(fun1, interval);

	function fun1() {
		now = Date.now();
		delta = now - then;
		
		//console.log(interval+" "+delta+" "+newEF);
		
		if (delta > interval || !newEF) {         
			then = now - (delta % interval);
			
			enterFrame();
			
			if (!newEF) setTimeout(fun1,interval);
	   }
	   
	   if (newEF) requestAnimationFrame(fun1); 
	}
	
	init();
}

function addEventListeners() {
    document.getElementById("inv-button").addEventListener("click", clickthrough);
    document.getElementById("btnleg").addEventListener("click", clickleg);
}

function clickthrough() {
	if (mode) {
	   TweenLite.to("#overlay",.2,{opacity:0,ease:Linear.easeNone});	
	   mode = 0;
	} else {
		console.log("click");
		var clickTAGvalue = dhtml.getVar('clickTAG', '');
		var landingpagetarget = dhtml.getVar('landingPageTarget', '_blank');
		window.open(clickTAGvalue,landingpagetarget);
	}
}

function clickleg() {
	if (mode) {
	   TweenLite.to("#overlay",.2,{opacity:0,ease:Linear.easeNone});	
	   mode = 0;
	} else {
	   TweenLite.to("#overlay",.2,{opacity:1,ease:Linear.easeNone});
	   mode = 1;
	}
}

function over1() {
 
}

function out1() {
 
}

	
	//drawProgress(167);

/////////////////////////////////////////////////////////////////////////////////


function valM(v) {
	return Math.floor(v)+" Monate";
}

function three(v) {
	var s = v+"";
	if (s.length==0) return "000"; else
	if (s.length==1) return "00"+s; else
	if (s.length==2) return "0"+s; else return s;
	
}

function valP(v) {
	var v2 = v % 1000;
	var v1 = (v-v2) / 1000;
	return v1+"."+three(v2);
}

var min = 29;
var max = 253;

var minM = 12;
var maxM = 120;

var minP = 4000;
var maxP = 50000;

var dist = (max-min);
var distM = (maxM-minM);
var distP = (maxP-minP);

var destP = (dist*4000)/distP+29;
var destM = (dist*6.3)/distM+29;

var destP2 = (dist*(30000-4000))/distP+29;
var destM2 = (dist*48)/distM+29;

var vp = [6000,8500,12000,14000,16000,20500,22000,26500,30000,8000];
var mp = [20,25,36,40,55,60,18];

var index = 0;

function updatePrice() {
		var price = document.getElementById("price");
		
        var ind = -1;
        var i;
		
		var b1 = document.getElementById("b1");
		var pos = parseInt(b1.style.left,10)-29;
		var p = Math.floor((distP*pos)/dist)+4000;

        
		for (i=0;i<vp.length;i++) {
			if (Math.abs(vp[i]-p)<200) {
				ind = i;
				break;
			}
		}
		
		
	 	if (ind!=-1) price.innerHTML = valP(vp[ind]);
}

function showPrices(callback) {
	//callback();
	var anim = 3.15;
	var delay = .6;
	destP = (dist*(vp[vp.length-2]-4000))/distP+29;
	var destP2 = (dist*(vp[vp.length-1]-4000))/distP+29;
	TweenLite.to("#b1",anim,{left:destP,ease:Sine.easeInOut,delay:delay, onComplete: function() {
		TweenLite.to("#b1",1,{left:destP2,ease:Sine.easeInOut,delay:0, onComplete: function() {
			updatePrice();
			callback();
		}});
	}, onUpdate: updatePrice});
}

function updateMonths() {
		var months = document.getElementById("months");
		
        var ind = -1;
        var i;
		
		var b2 = document.getElementById("b2");
		var pos = parseInt(b2.style.left,10)-29;
		var p = Math.floor((distM*pos)/dist)+12;

        
		for (i=0;i<mp.length;i++) {
			if (Math.abs(mp[i]-p)<2) {
				ind = i;
				break;
			}
		}
		
		
	 	if (ind!=-1) months.innerHTML = valM(mp[ind]);
}

function showMonths(callback) {
	//callback();
	var anim = 3.15;
	var delay = .6;
	destM = (dist*(mp[mp.length-2]-12))/distM+29;
	var destM2 = (dist*(mp[mp.length-1]-12))/distM+29;
	TweenLite.to("#b2",anim,{left:destM,ease:Sine.easeInOut,delay:delay, onComplete: function() {
		TweenLite.to("#b2",1,{left:destM2,ease:Sine.easeInOut,delay:0, onComplete: function() {
			updateMonths();
		    callback();
		}});
	}, onUpdate: updateMonths});
}

function empty() {
	
}

function init() {
    var i;
	
	TweenLite.to("#txt2",.5,{opacity:1,ease:Linear.easeNone, delay:1.2, onComplete: function() {	
	
	   TweenLite.to("#txt1,#txt2",.5,{opacity:0,ease:Linear.easeNone, delay:2.3, onComplete: function() {	   
		   TweenLite.to("#form",.5,{opacity:1,ease:Linear.easeNone, delay:.7});	
			   TweenLite.fromTo("#kredit1",.2,{scale:5},{opacity:1,scale:1,rotation:0,ease:Sine.easeIn, delay:0, onComplete: function() {
				   TweenLite.to("#kredit1",.06,{scale:1.05, ease:Sine.easeOut, onComplete: function() {	   
				     TweenLite.to("#kredit1",.03,{scale:1, ease:Sine.easeInOut, onComplete: function() {
						 
					   showMonths(empty);
						 
					   TweenLite.to("#kredit1",.3,{scaleX:.01,ease:Quad.easeIn, delay:2.6, onComplete: function() {
						  TweenLite.fromTo("#volle1",.3,{scaleX:-.01, opacity:1},{scaleX:1, opacity:1,ease:Quad.easeInOut, delay:0, onComplete: function() { 

							   TweenLite.to("#volle1",.3,{scaleX:.01,ease:Quad.easeIn, delay:3, onComplete: function() {
								  TweenLite.set("#volle1",{opacity:0});
								  TweenLite.fromTo("#kredit1",.3,{scaleX:-.01, opacity:1},{scaleX:1, opacity:1,ease:Quad.easeInOut, delay:0, onComplete: function() { 
									   TweenLite.to("#kredit1",.3,{scaleX:.01,ease:Quad.easeIn, delay:3, onComplete: function() {
										  TweenLite.fromTo("#volle1",.3,{scaleX:-.01, opacity:1},{scaleX:1, opacity:1,ease:Quad.easeInOut, delay:0, onComplete: function() { 
										  
										  }}); 
									   }});
								  }}); 
							   }});
						  
						  }}); 
					   }});
						 
						 showPrices(function() {
						 });
						 

					 }});	 
				   }});
			   }});
		   }});   
	}});
}

function progress1() {
	var b1 = document.getElementById("b1");
	var price = document.getElementById("price");
	var pos = parseInt(b1.style.left,10)-29;
	
	var p = Math.floor((distP*pos)/dist)+4000;
	//console.log(pos,p);
	if (Math.abs(p-8000)<100) p = 8000;
	if (Math.abs(p-30000)<100) p = 30000;
	
	price.innerHTML = valP(p);
	
}

function progress2() {
	var b2 = document.getElementById("b2");
	var months = document.getElementById("months");
	var pos = parseInt(b2.style.left,10)-29;
	
	var p = Math.floor((distM*pos)/dist)+12;
	console.log(pos,p,distM);
	
	months.innerHTML = valM(p);
	
}


function repeat() {
  var i;
  for (i=0;i<tweens.length;i++){
    tweens[i].pause(0);
  }
  
  
}

function enterFrame() {
}
